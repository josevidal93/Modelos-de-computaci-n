
/*
 - Z2={0,1}
 -frontera cilindrica
 -T = ((ai-1 * a1+1)+ai)%2
*/
public interface ca1DSim{
	public void nextGen();
	public void caComputation(int nGen);
}

