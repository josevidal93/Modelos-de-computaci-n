# BelZhab
Belousov-Zhabotinsky chemical reaction, modelled using a 2-dimensional multi-value cellular automata.

### Usage
Speed-up times
<code>java Speedup &lt;size&gt; &lt;tasks&gt;</code>

GUI
<code>java MainGrafico</code>
